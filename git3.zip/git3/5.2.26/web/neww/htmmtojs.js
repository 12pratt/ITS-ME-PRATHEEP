function validateform(){
    var username= document.getElementById("username").value;
    var password= document.getElementById("password").value;
    if(username=="")
        {
        alert ("USERNAME CANNOT BE EMPTY");
        return false;}
    if(password==""){
        alert ("PASSWORD CANNOT BE EMPTY");
        return false;
    } if(username=="pratt" && password=="pratt")
        {
            window.open();
        return false;
        
    }
    i

}
    