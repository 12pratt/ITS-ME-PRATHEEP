package com.example.demo.Repos;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.Employee;

public interface MyRepo extends JpaRepository<Employee, Integer> {
}