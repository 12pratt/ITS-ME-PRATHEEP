package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeLoginThymeleafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeLoginThymeleafeApplication.class, args);
	}

}
