package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeController {

    @GetMapping("/employees")
    public List<Employee> getEmployees() {
        return Arrays.asList(
                new Employee(1, "sakthi"),
                new Employee(2, "Ravi"),
                new Employee(3, "mathi"));
    }
}