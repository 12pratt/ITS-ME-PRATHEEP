import { Component } from '@angular/core';
import { AuthService } from '../auth-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone:true,
  imports: [],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
 constructor(private auth: AuthService, private router: Router) {}
login() {
    this.auth.login();
    this.router.navigate(['/dashboard']);
  }
}