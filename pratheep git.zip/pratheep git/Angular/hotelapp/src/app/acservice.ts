import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Acservice {
  turnOn(){
  return "Ac is ON"
}
turnOff(){
  return"Ac is OFF"
}  
  
}
