package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repos.MyRepo;
import com.example.demo.entity.Employee;
import com.example.demo.Exceptions.*;
@Service
public class MyServices {

    @Autowired
    private MyRepo repo;

    // Get all employees
    public List<Employee> getAllEmployee() {
        return repo.findAll();
    }

    // Get employee by ID
    public Employee getEmployeebyId(int id) {
        return repo.findById(id)
                .orElseThrow(() ->
                        new EmployeeNotFoundException("Employee not found with id " + id));
    }

    // Add employee
    public String addEmployee(Employee employee) {
        repo.save(employee);
        return "Employee added successfully";
    }

    // Update employee
    public String updateEmployee(int id, Employee updatedEmployee) {

        Employee existingEmployee = repo.findById(id)
                .orElseThrow(() ->
                        new EmployeeNotFoundException("Employee not found with id " + id));

        existingEmployee.setName(updatedEmployee.getName());
        existingEmployee.setAge(updatedEmployee.getAge());
        existingEmployee.setSalary(updatedEmployee.getSalary());
        existingEmployee.setDesig(updatedEmployee.getDesig());

        repo.save(existingEmployee);

        return "Employee updated successfully";
    }

    // Delete employee
    public String deleteEmployee(int id) {

        if (!repo.existsById(id)) {
            throw new EmployeeNotFoundException("Employee not found with id " + id);
        }

        repo.deleteById(id);
        return "Employee deleted successfully";
    }

    // Delete all employees
    public String deleteAllEmployee() {
        repo.deleteAll();
        return "All employees deleted successfully";
    }
}