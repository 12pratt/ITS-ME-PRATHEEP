import { Component, signal } from '@angular/core';
import { ROUTER_OUTLET_DATA, RouterOutlet } from '@angular/router';
import { Test } from "./test/test";
import { Structural } from './structural/structural';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Test,Structural],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('directives');
}
