function validateform() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (username === "") {
        alert("USERNAME CANNOT BE EMPTY");
        return false;
    }

    if (password === "") {
        alert("PASSWORD CANNOT BE EMPTY");
        return false;
    }

    if (username === "pratt" && password === "pratt") {
        window.location.href = "ome.html"; // redirect
        return false;
    }

    alert("Invalid username or password");
    return false;
}
