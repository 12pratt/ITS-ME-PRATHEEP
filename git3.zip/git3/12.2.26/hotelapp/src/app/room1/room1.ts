import { Component } from '@angular/core';
import { Acservice } from '../acservice';

@Component({
  selector: 'app-room1',
  imports: [],
  templateUrl: './room1.html',
  styleUrl: './room1.css',
})
export class Room1 {
   message=''
  constructor  ( private serviceac: Acservice){

  
  }
acOn(){

  this.message=this.serviceac.turnOn();
}
acOff(){

  this.message=this.serviceac.turnOff();
}


}
