import { Component, OnInit, signal } from '@angular/core';
import { EmployeeService } from './services/employee-services';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.css'
})
export class App implements OnInit {

  protected readonly title = signal('anand-frontend');
employees: any[] = [];
constructor(private empService: EmployeeService) {}
ngOnInit() {
    this.empService.getEmployees().subscribe(data => {
      this.employees = data;
    });
  }

}