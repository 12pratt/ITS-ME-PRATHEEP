import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  standalone:true,
  imports: [FormsModule],
  templateUrl: './data-binding.html',
  styleUrl: './data-binding.css',
})
export class DataBinding {
  //sting interpolation
  name="pratheep";
  //property binding
  isDisabled = false;
  //event binding
  enableButton(){
    this.isDisabled = true; 
  }
  //two way binding
  username ='';
  showAlert(){
    alert('Hello'+this.username)
  }
}
