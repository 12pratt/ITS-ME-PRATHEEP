package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeLoginThymeleafe2Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeLoginThymeleafe2Application.class, args);
	}

}
