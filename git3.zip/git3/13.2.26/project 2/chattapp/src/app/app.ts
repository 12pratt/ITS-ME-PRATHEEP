import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ChatComponent } from "./chat.component/chat.component";

@Component({
  selector: 'app-root',
  imports: [ FormsModule, ChatComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('chatapp');
}
