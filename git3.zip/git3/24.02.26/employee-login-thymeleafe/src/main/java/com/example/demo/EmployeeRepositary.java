package com.example.demo;

public class EmployeeRepositary {

}
